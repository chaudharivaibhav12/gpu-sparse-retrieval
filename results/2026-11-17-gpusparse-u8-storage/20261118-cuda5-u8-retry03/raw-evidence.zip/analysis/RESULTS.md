# Compact-weight full-collection results — November 18, 2026

Measured source f263feed61a47f9b6317fff45df9788430b0ff2c, run20261118-cuda5-u8-retry03. Full8,841,823passages,500calibration queries,RTX4070,k10,batch1,3processes/system,3warmup/20measuredrounds,matched complete resident-query wall boundary. Held-out6480untouched.

| System | Descriptive median ms | Sampled own GPU peak MiB |
|---|---:|---:|
| Arnav-derived range W1024/T256 |0.685663|3668|
| Guarded canonical FP32 GPUSparse, FP32 storage |6.006736|8324|
| Guarded canonical FP32 GPUSparse, uint8 storage |5.873649|5322|

Primary compact/control paired geometric latency ratio0.9806963, conditional95%interval0.9798005–0.9815498:1.9304%less time (1.8450–2.0199%). Sampled own peak drops3002MiB/36.0644%; modeled tensor storage saving3,147,846,558bytes has a different scope. Memory sampling is not an exact physical peak.

Range/compact paired inverse8.2680643x, conditional95%interval8.1442537–8.3897476. Fresh range/FP32-storage inverse8.4308105x. These use paired geometric per-query/process20-round medians, not divisions of displayed descriptive medians. Intervals use10000crossed process/query bootstrap draws, conditional on this calibration set/session.

Interpretation: uint8 storage strengthens the disclosed adapted baseline, especially its memory footprint, while reducing query time modestly. Retain compact as the stronger measured adapted latency control and report both. The range algorithm is unchanged; this is not a new algorithmic improvement over Arnav's scorer or a CPU speedup. No approximation or original arbitrary-float relevance claim.

Validation:42serverprotocolsteps completed. Independent local replay checked105249querygroups/1051740rankedscores, all nine timing processes and their declared sample ordering, source/runtime artifact hashes, and all three10000-draw contrasts. Full outputs match the pinned independent CPU oracle; synthetic outputs were recomputed exhaustively. Scoring byte-load/unsignedFP32conversion/product/atomic evidence passed the repaired target verifier before timing. Raw evidence archive SHA256b2036835f36a31e6ec435136fedcc5065d6b5dc6f6fbb94fd48950df35e60454 is preserved locally. Original fullGSP remains remote; source-row proof is inherited from accepted oracle validation, with no fresh local fullCIFFposting replay.

All failed attempts remain preserved: occupancy stops on original/retry01, then a TTIR verifier false negative on retry02. Final retry03 passes without changing scoring/storage treatment/timing settings. The wait repair changes only resource orchestration; the verifier repair recognizes actual pointer annotation and binds SSA conversion. No completed timing was manufactured from failed attempts.

Next: prepare final public report/package and review it before publication. Full CPU-BMP, broader workloads and component attribution remain separate questions. No new measurement or held-out tuning is needed to report this completed study.
