"""Untimed provenance extraction from GSP bytes; no Torch, model or GPU imports."""
import argparse,csv,hashlib,json,mmap,struct,sys
from pathlib import Path

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def extract(index,positions,output,expected_hash):
    index=Path(index);output=Path(output)
    assert not output.exists() and digest(index)==expected_hash
    positions=sorted(set(positions));count=0
    with index.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        assert data[:8]==b'GSPIDX01'
        n,v,nnz=struct.unpack_from('<IIQ',data,8)
        assert all(0<=p<n for p in positions)
        id_start=24;offset_start=id_start+n*8;term_start=offset_start+(n+1)*8;impact_start=term_start+nnz*4
        assert len(data)>=impact_start+nnz+4*v
        assert struct.unpack_from('<Q',data,offset_start)[0]==0
        assert struct.unpack_from('<Q',data,offset_start+n*8)[0]==nnz
        with output.open('x',encoding='utf-8',newline='\n') as out:
            for p in positions:
                lo,hi=struct.unpack_from('<QQ',data,offset_start+p*8)
                assert 0<=lo<=hi<=nnz
                original=struct.unpack_from('<Q',data,id_start+p*8)[0]
                terms=struct.unpack_from('<'+'I'*(hi-lo),data,term_start+lo*4)
                impacts=list(data[impact_start+lo:impact_start+hi])
                assert len(set(terms))==len(terms) and all(t<v for t in terms)
                row=dict(position=p,original_id=original,terms=list(zip(terms,impacts)),csr_offsets=[lo,hi])
                out.write(json.dumps(row,separators=(',',':'))+'\n');count+=1
    assert digest(index)==expected_hash
    return dict(rows=count,index_sha256=expected_hash,documents=n,vocabulary=v,nnz=nnz,output_sha256=digest(output),qualification='Untimed derived CSR-row extraction for local independent returned-score validation. Full index is hash-bound remotely; partial rows do not independently prove their membership against that hash without the bulk index.')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',required=True);a=parser.parse_args()
    root=Path(a.root);status=json.loads((root/'gpusparse-u64-status.json').read_text());assert status['state']=='complete','Never extract during query measurements'
    run=root/'results/2026-11-12-gpusparse-u64-canonical/20261112-cuda5-01';positions=set();files=[]
    for p in sorted((run/'raw').glob('*.tsv')):
        if not (p.name.startswith('real-gsp-') or (p.name.startswith('timing-') and 'gpusparse-u64' in p.name)):continue
        with p.open(newline='') as f:
            for row in csv.DictReader(f,delimiter='\t'):positions.add(int(row['internal_doc_position']))
        files.append(dict(name=p.name,sha256=digest(p)))
    assert len(files)==5
    output=run/'analysis/candidate-rows.jsonl'
    report=extract(root/'data/derived/hash-1000000.gsp',positions,output,'a7249ab0fafcfb1bff754e960063c5982f92e509f40d5ebbfda6a06cbb3e3c37')
    report.update(command=sys.argv,python=sys.version,source_sha256=digest(__file__),input_top_files=files)
    with (run/'analysis/candidate-rows-manifest.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(report))

if __name__=='__main__':main()
